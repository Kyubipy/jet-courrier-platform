import React, { useEffect, useState } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  SafeAreaView, 
  TouchableOpacity,
  FlatList,
  Alert 
} from 'react-native';
import axios from 'axios';

const API_URL = 'https://jet-courrier-api.onrender.com';

export default function DashboardScreen({ route, navigation }) {
  const { user, token } = route.params;
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchOrders();
  }, []);

  const fetchOrders = async () => {
    setLoading(true);
    try {
      const response = await axios.get(`${API_URL}/api/orders/delivery/${user.id}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setOrders(response.data.orders);
    } catch (error) {
      console.log('Error fetching orders:', error.response?.data || error.message);
    }
    setLoading(false);
  };

  const renderOrder = ({ item }) => (
    <View style={styles.orderCard}>
      <Text style={styles.orderAddress}>Desde: {item.pickup_address}</Text>
      <Text style={styles.orderAddress}>Hasta: {item.delivery_address}</Text>
      <Text style={styles.orderStatus}>Estado: {item.status}</Text>
      <Text style={styles.orderPrice}>Pago: ₲{item.delivery_payment}</Text>
    </View>
  );

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Bienvenido {user.full_name}</Text>
        <TouchableOpacity 
          style={styles.logoutButton}
          onPress={() => navigation.replace('Login')}
        >
          <Text style={styles.logoutText}>Salir</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.content}>
        <Text style={styles.sectionTitle}>Mis Pedidos</Text>
        
        {loading ? (
          <Text style={styles.loadingText}>Cargando pedidos...</Text>
        ) : orders.length > 0 ? (
          <FlatList
            data={orders}
            renderItem={renderOrder}
            keyExtractor={(item) => item.id.toString()}
            style={styles.ordersList}
          />
        ) : (
          <Text style={styles.noOrdersText}>No tienes pedidos asignados</Text>
        )}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f9fa'
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    backgroundColor: 'white',
    borderBottomWidth: 1,
    borderBottomColor: '#e1e8ed'
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#2c3e50'
  },
  logoutButton: {
    padding: 8,
    backgroundColor: '#e74c3c',
    borderRadius: 8
  },
  logoutText: {
    color: 'white',
    fontWeight: '600'
  },
  content: {
    flex: 1,
    padding: 20
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 16,
    color: '#2c3e50'
  },
  orderCard: {
    backgroundColor: 'white',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#e1e8ed'
  },
  orderAddress: {
    fontSize: 14,
    color: '#2c3e50',
    marginBottom: 4
  },
  orderStatus: {
    fontSize: 14,
    color: '#7f8c8d',
    marginBottom: 4
  },
  orderPrice: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#27ae60'
  },
  loadingText: {
    textAlign: 'center',
    color: '#7f8c8d',
    marginTop: 20
  },
  noOrdersText: {
    textAlign: 'center',
    color: '#7f8c8d',
    marginTop: 20
  },
  ordersList: {
    flex: 1
  }
});