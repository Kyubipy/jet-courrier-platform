import React from 'react';
import OrderTracking from './components/OrderTracking';

function App() {
  const testOrder = { id: 1, pickup_address: 'Test', delivery_address: 'Test' };
  return <OrderTracking order={testOrder} onBack={() => {}} />;
}

export default App;