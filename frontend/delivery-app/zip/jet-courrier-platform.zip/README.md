# jet-courrier-platform
Central Nacional de Deliverys en Paraguay
